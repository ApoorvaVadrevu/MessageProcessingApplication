package messages;
class Product{

      String p_name;
      Integer p_quantity;
      Integer p_price;
      
       Product(String n,Integer q,Integer p){
              p_name=n;
              p_quantity=q;
              p_price=p;
              
              
     }
 }


