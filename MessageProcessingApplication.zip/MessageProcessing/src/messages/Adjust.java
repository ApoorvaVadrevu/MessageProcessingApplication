package messages;

class Adjust{

    String task;
    String product;
Integer value;
    Adjust(String n,String p,Integer q){{
        task=n;
        product=p;
        value=q;

        
    }
}
}